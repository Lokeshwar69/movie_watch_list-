import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col, Button, Form, ListGroup, Badge } from 'react-bootstrap';
import './App.css';

function App() {
  const [movies, setMovies] = useState([]);
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('');
  const [watched, setWatched] = useState(false);
  const [rating, setRating] = useState('');
  const [filter, setFilter] = useState('all');
  const [editingId, setEditingId] = useState(null);

  // Fetch movies
  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/movies');
      setMovies(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const movie = { title, genre, watched, rating: rating || null };

    try {
      if (editingId) {
        await axios.put(`http://localhost:5000/api/movies/${editingId}`, movie);
        setEditingId(null);
      } else {
        await axios.post('http://localhost:5000/api/movies', movie);
      }
      fetchMovies();
      resetForm();
    } catch (err) {
      console.error(err);
    }
  };

  // Edit movie
  const handleEdit = (movie) => {
    setTitle(movie.title);
    setGenre(movie.genre);
    setWatched(movie.watched);
    setRating(movie.rating || '');
    setEditingId(movie._id);
  };

  // Delete movie
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/movies/${id}`);
      fetchMovies();
    } catch (err) {
      console.error(err);
    }
  };

  // Reset form
  const resetForm = () => {
    setTitle('');
    setGenre('');
    setWatched(false);
    setRating('');
    setEditingId(null);
  };

  // Filter movies
  const filteredMovies = movies.filter((movie) => {
    if (filter === 'watched') return movie.watched;
    if (filter === 'unwatched') return !movie.watched;
    return true;
  });

  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Movie Watchlist</h1>
      <Row>
        <Col md={6}>
          <h3>{editingId ? 'Edit Movie' : 'Add Movie'}</h3>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Genre</Form.Label>
              <Form.Control
                type="text"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Check
                type="checkbox"
                label="Watched"
                checked={watched}
                onChange={(e) => setWatched(e.target.checked)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Rating (1-5)</Form.Label>
              <Form.Control
                type="number"
                min="1"
                max="5"
                value={rating}
                onChange={(e) => setRating(e.target.value)}
              />
            </Form.Group>
            <Button type="submit" variant="primary" className="me-2">
              {editingId ? 'Update' : 'Add'}
            </Button>
            <Button variant="secondary" onClick={resetForm}>
              Clear
            </Button>
          </Form>
        </Col>
        <Col md={6}>
          <h3>Movies</h3>
          <Form.Group className="mb-3">
            <Form.Label>Filter</Form.Label>
            <Form.Select onChange={(e) => setFilter(e.target.value)}>
              <option value="all">All</option>
              <option value="watched">Watched</option>
              <option value="unwatched">Unwatched</option>
            </Form.Select>
          </Form.Group>
          <ListGroup>
            {filteredMovies.map((movie) => (
              <ListGroup.Item key={movie._id} className="d-flex justify-content-between align-items-center">
                <div>
                  <h5>{movie.title}</h5>
                  <p>Genre: {movie.genre}</p>
                  <p>Status: {movie.watched ? 'Watched' : 'Unwatched'}</p>
                  {movie.rating && <Badge bg="info">Rating: {movie.rating}/5</Badge>}
                </div>
                <div>
                  <Button variant="outline-primary" size="sm" className="me-2" onClick={() => handleEdit(movie)}>
                    Edit
                  </Button>
                  <Button variant="outline-danger" size="sm" onClick={() => handleDelete(movie._id)}>
                    Delete
                  </Button>
                </div>
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Col>
      </Row>
    </Container>
  );
}

export default App;